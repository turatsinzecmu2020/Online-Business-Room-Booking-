<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Fontfaces CSS-->
    <link href="../../admin/css/font-face.css" rel="stylesheet" media="all">
    <link href="../../admin/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="../../admin/vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="../../admin/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="../../admin/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="../../admin/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="../../admin/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="../../admin/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="../../admin/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="../../admin/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="../../admin/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="../../admin/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="../../admin/css/theme.css" rel="stylesheet" media="all">

    <!-- Jquery JS-->
    <script src="../../admin/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="../../admin/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="../../admin/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="../../admin/vendor/slick/slick.min.js">
    </script>
    <script src="../../admin/vendor/wow/wow.min.js"></script>
    <!--<script src="../admin/vendor/animsition/animsition.min.js"></script>-->
    <script src="../../admin/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="../../admin/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="../../admin/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="../../admin/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="../../admin/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="../../admin/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="../../admin/vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="../../admin/js/main.js"></script>
    <script src="../../js/operations.js"></script>
</head>

<body>


<?php
include "../config/connection.php";
?>

<?php

session_start();

        $username=$_POST["username1"];
        $password=$_POST["password1"];
        $username = stripslashes($username);
        $password = stripslashes($password);
        $username = mysqli_real_escape_string($conn,$username);
        $password = mysqli_real_escape_string($conn,$password);

    if(empty($username) || empty($password)){
        ?>
        <div class="alert alert-danger" role="alert">
        <i class='fa fa-times-circle'></i> Invalid username or password
            </div>
        <?php
    }else{

    $query=$conn->query("SELECT * from customer where username='$username' and password='$password'");
    if($query->num_rows ==1){

      $sql4="SELECT * from customer where username like '$username'";
      $result4=$conn->query($sql4);

        if ($row4 = $result4->fetch_assoc()) {
            $username_real=$row4['username'];
            $password_real=$row4['password'];

        }

          if ($username===$username_real and $password===$password_real){
                
                 $_SESSION['expo_client_2019']=$username;
                  ?>
                  <div class="alert alert-success" role="alert">
                  <i class='fa  fa-check-circle'></i> Login successfull. Redirecting ...
                      </div>
                  <?php
                  echo "<script>location.href='client/index.php'</script>";    
              }else{
                   ?>
                   <div class="alert alert-danger" role="alert">
                   <i class='fa fa-times-circle'></i> Invalid Username or Password 
                    </div>
                   <?php
             }

          }
          else{

                 $query1=$conn->query("SELECT * from manager where username='$username' and password='$password'");
                        if($query1->num_rows == 1){

                    $sql5="SELECT * from manager where username like '$username'";
                    $result5=$conn->query($sql5);

                      if ($row5 = $result5->fetch_assoc()) {
                          $username_real1=$row5['username'];
                          $password_real1=$row5['password'];

                      }

                if ($username===$username_real1 and $password===$password_real1){
                            
                        
                         $_SESSION['expo_manager_2019']=$username;
                         ?>
                         <div class="alert alert-success" role="alert">
                         <i class='fa  fa-check-circle'></i> Login successfull. Redirecting . . . .
                          </div>
                         <?php
                         echo "<script>location.href='manager/index.php'</script>";
                    }
                    
                    else{
                      ?>
                      <div class="alert alert-danger" role="alert">
                      <i class='fa fa-times-circle'></i> Dear Client Something went wrong. Please login later.
                       </div>
                      <?php
                    }

         }else{
                        $query1=$conn->query("SELECT * from admin where username='$username' and password='$password'");
                        if($query1->num_rows == 1){

                    $sql5="SELECT * from admin where username like '$username'";
                    $result5=$conn->query($sql5);

                      if ($row5 = $result5->fetch_assoc()) {
                          $username_real1=$row5['username'];
                          $password_real1=$row5['password'];

                      }

                if ($username===$username_real1 and $password===$password_real1){
                            
                        
                         $_SESSION['expo_admin_2019']=$username;
                         ?>
                         <div class="alert alert-success" role="alert">
                         <i class='fa  fa-check-circle'></i> Login successfull. Redirecting . . . .
                          </div>
                         <?php
                         echo "<script>location.href='admin/index.php'</script>";
                    }
                    
                    else{
                      ?>
                      <div class="alert alert-danger" role="alert">
                      <i class='fa fa-times-circle'></i> Dear Client Something went wrong. Please login later.
                       </div>
                      <?php
                    }
      }
                
      }

      }
}

?>

</body>
</html>