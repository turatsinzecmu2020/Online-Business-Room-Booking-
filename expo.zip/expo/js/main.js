

function Ben_way_to_get_element(el){
  return document.getElementById(el);
}

function ajax_changetab_and_send_data(php_file, el, send_data){
  var hr=new XMLHttpRequest();
  hr.open('POST', php_file, true);
  hr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

  hr.onreadystatechange=function(){
      if(hr.readyState==4 && hr.status==200){
          Ben_way_to_get_element(el).innerHTML=hr.responseText;
      }
  };

  hr.send(send_data);
}


function mySearchFunction1() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("Search");
  filter = input.value.toUpperCase();
  table = document.getElementById("Tb1");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}

function mySearchFunction2() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("Search1");
  filter = input.value.toUpperCase();
  table = document.getElementById("Tb1");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[8];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}



function login1(){

 Ben_way_to_get_element('Message1').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Authenticating …</div>";

 var username1=$('#username1').val();
 var password1=$('#password1').val();
 
 $.ajax({
     type:'POST',
     url: 'js/login1.php',
     data:{
         username1:username1,
         password1:password1,
 
     },
     
     success: function (response){
         $("#Message1").html(response);
     }
 
 });
 
 }

 function view_data(){

 Ben_way_to_get_element('test_view').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Fetching Design . . . . </div>";

 var username1=$('#username1').val();
 var password1=$('#password1').val();
 
 $.ajax({
     type:'POST',
     url: 'query/login1.php',
     data:{
         username1:username1,
         password1:password1,
 
     },
     
     success: function (response){
         $("#Message1").html(response);
     }
 
 });
 
 }

 $(document).ready(function(){

    // new deapt

    $("#add_general_admin").click(function(){
      $("#loader_general_admin1").fadeOut(500);  
      setTimeout(function(){ ajax_changetab_and_send_data('manager_data/new_department.php', 'loader_general_admin', null); }, 500);
      });

    // new manager

    $("#add_new_manager").click(function(){
      $("#loader_general_admin1").fadeOut(500);  
      setTimeout(function(){ ajax_changetab_and_send_data('manager_data/new_manager.php', 'loader_general_admin', null); }, 500);
      });

    // new stand

    $("#add_new_stand").click(function(){
      $("#loader_general_admin1").fadeOut(500);  
      setTimeout(function(){ ajax_changetab_and_send_data('manager_data/new_stand.php', 'loader_general_admin', null); }, 500);
      });

    

});

// new user

function new_client(){
        Ben_way_to_get_element('new_client_message').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Creating New Account for you . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var CustName=Ben_way_to_get_element('CustName').value;
        var Origin=Ben_way_to_get_element('Origin').value;
        var Identification=Ben_way_to_get_element('Identification').value;
        var CommDocument=Ben_way_to_get_element('CommDocument').files[0];
        var username=Ben_way_to_get_element('username').value;
        var email=Ben_way_to_get_element('email').value;
        var contact=Ben_way_to_get_element('contact').value;
        var username=Ben_way_to_get_element('username').value;
        var password=Ben_way_to_get_element('password').value;
      
        formdata.append('CustName',CustName);
        formdata.append('Origin',Origin);
        formdata.append('Identification',Identification);
        formdata.append('CommDocument',CommDocument);
        formdata.append('username',username);
        formdata.append('email',email);
        formdata.append('contact',contact);
        formdata.append('username',username);
        formdata.append('password',password);
      
        ajax1.open('POST', 'client/account-data/new_user.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('new_client_message').innerHTML=ajax1.responseText;
      
        }; 
}

// updating reservation slip

function upload_bank_slip(){
        Ben_way_to_get_element('bank_slip_data').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Uploading Bank Slip . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var ResID=Ben_way_to_get_element('ResID').value;
        var slip=Ben_way_to_get_element('slip').files[0];
      
        formdata.append('ResID',ResID);
        formdata.append('slip',slip);;
      
        ajax1.open('POST', 'account-data/reservation_slip.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('bank_slip_data').innerHTML=ajax1.responseText;
      
        }; 
}

// new dept

function new_department(){
        Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Saving New Department . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var name=Ben_way_to_get_element('name').value;
        var numstand=Ben_way_to_get_element('numstand').value;
        var stprice=Ben_way_to_get_element('stprice').value;
      
        formdata.append('name',name);
        formdata.append('numstand',numstand);
        formdata.append('stprice',stprice);
      
        ajax1.open('POST', 'manager_data/new_dept.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;
      
        }; 
} 

// new manager

function new_manager(){
        Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Saving New Manager . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var username=Ben_way_to_get_element('username').value;
        var password=Ben_way_to_get_element('password').value;
      
        formdata.append('username',username);
        formdata.append('password',password);
      
        ajax1.open('POST', 'manager_data/new_man.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;
      
        }; 
} 


// new stand

function new_stand(){
        Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Saving New Stand . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var dept=Ben_way_to_get_element('dept').value;
        var standno=Ben_way_to_get_element('standno').value;
        var height=Ben_way_to_get_element('height').value;
        var width=Ben_way_to_get_element('width').value;
      
        formdata.append('dept',dept);
        formdata.append('standno',standno);
        formdata.append('height',height);
        formdata.append('width',width);
      
        ajax1.open('POST', 'manager_data/new_stand_data.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;
      
        }; 
}

// new reservation

function new_reservation(){
        Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Sending Your Reservation . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var stand_id=Ben_way_to_get_element('stand_id').value;
        var cust_id=Ben_way_to_get_element('cust_id').value;

        formdata.append('stand_id',stand_id);
        formdata.append('cust_id',cust_id);
      
        ajax1.open('POST', 'account-data/new_reservation.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;
      
        }; 
}

// update stand

function update_stand(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var StID=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&StID="+StID;
     ajax_changetab_and_send_data('manager_data/update_stand.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// updtae dept

function update_general_admin(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var DeptID=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&DeptID="+DeptID;
     ajax_changetab_and_send_data('manager_data/update_dept.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// delete dept

function delete_dept(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var DeptID=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&DeptID="+DeptID;
     ajax_changetab_and_send_data('manager_data/delete_dept.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// delete man

function delete_manager(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var DeptID=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&DeptID="+DeptID;
     ajax_changetab_and_send_data('manager_data/delete_man.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// update department

function update_general_admin_file(){
  Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Department . . . . </div>";

  var formdata=new FormData();
  var ajax1=new XMLHttpRequest();

  var DeptID=Ben_way_to_get_element('DeptID').value;
  var name=Ben_way_to_get_element('name').value;
  var numstand=Ben_way_to_get_element('numstand').value;
  var stprice=Ben_way_to_get_element('stprice').value;

  formdata.append('DeptID',DeptID);
  formdata.append('name',name);
  formdata.append('numstand',numstand);
  formdata.append('stprice',stprice);

  ajax1.open('POST', 'manager_data/update_data.php'); //third argument can be true or false which is optional
  ajax1.send(formdata);

  ajax1.onreadystatechange=function(){
      Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;

  }; 
} 




// update Stands

function update_stand_data(){
  Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Stand . . . . </div>";

  var formdata=new FormData();
  var ajax1=new XMLHttpRequest();

  var StID=Ben_way_to_get_element('StID').value;
  var standno=Ben_way_to_get_element('standno').value;
  var heigth=Ben_way_to_get_element('heigth').value;
  var width=Ben_way_to_get_element('width').value;

  formdata.append('StID',StID);
  formdata.append('standno',standno);
  formdata.append('heigth',heigth);
  formdata.append('width',width);

  ajax1.open('POST', 'manager_data/update_stand_data.php'); //third argument can be true or false which is optional
  ajax1.send(formdata);

  ajax1.onreadystatechange=function(){
      Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;

  }; 
}

// Approve Stands booking

function approve_stand_data(){
  Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Approving Stand Data . . . . </div>";

  var formdata=new FormData();
  var ajax1=new XMLHttpRequest();

  var reserv_id=Ben_way_to_get_element('reserv_id').value;

  formdata.append('reserv_id',reserv_id);

  ajax1.open('POST', 'manager_data/approve_stand.php'); //third argument can be true or false which is optional
  ajax1.send(formdata);

  ajax1.onreadystatechange=function(){
      Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;

  }; 
}

// Decline Stands booking

function decline_stand(){
  Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Declining Stand Data reservation . . . . </div>";

  var formdata=new FormData();
  var ajax1=new XMLHttpRequest();

  var reserv_id=Ben_way_to_get_element('reserv_id').value;

  formdata.append('reserv_id',reserv_id);

  ajax1.open('POST', 'manager_data/decline_stand.php'); //third argument can be true or false which is optional
  ajax1.send(formdata);

  ajax1.onreadystatechange=function(){
      Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;

  }; 
}


// testimon

function new_testimonial(){
        Ben_way_to_get_element('new_testimonial_message').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Sending your testimonial . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var username=Ben_way_to_get_element('username').value;
        var email=Ben_way_to_get_element('email').value;
        var cont_message=Ben_way_to_get_element('cont_message').value;
      
        formdata.append('username',username);
        formdata.append('email',email);
        formdata.append('cont_message',cont_message);
      
        ajax1.open('POST', 'account-data/suggestion.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('new_testimonial_message').innerHTML=ajax1.responseText;
      
        }; 
}

// dead line

function dead_line(){
        Ben_way_to_get_element('new_testimonial_message').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Setting Expo Dead Line . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var dead_date=Ben_way_to_get_element('dead_date').value;
      
        formdata.append('dead_date',dead_date);
      
        ajax1.open('POST', 'manager_data/dead_line.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('new_testimonial_message').innerHTML=ajax1.responseText;
      
        }; 
}