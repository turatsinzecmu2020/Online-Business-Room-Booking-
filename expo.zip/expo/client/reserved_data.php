                <div class="container-fluid">
                     <div id="bank_slip_data" style="position:fixed;z-index:500;margin-top:-2%;"></div>
                     <br>
                        
                        <div id="loader_general_admin"></div>

                      <div class="row" id="loader_general_admin1">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <h3 class="title-5 m-b-35">Reserved Stand List</h3>
                                <div class="table-data__tool">
                                </div>
                                            <?php

                                                $sql5="SELECT * from reservation where CustID='$CID' ";
                                                $result5=$conn->query($sql5);

                                                $a=1;

                                                while ($row5 = $result5->fetch_assoc()) {
                                                $ResID=$row5['ResID'];
                                                $CustID=$row5['CustID'];
                                                $StandID=$row5['StandID'];
                                                $Date=$row5['Date'];
                                                $Status=$row5['Res_Status'];
                                                $Decision=$row5['Decision'];
                                                $Slip=$row5['Slip'];

                                                $id1="Mine".$a;
                                                $id2="Mine1".$a;

                                                $sql6="SELECT * from stands where StID='$StandID'";
                                                $result6=$conn->query($sql6);

                                                while ($row6 = $result6->fetch_assoc()) {
                                                $name=$row6['StandNo'];

                                        if ( ! empty($Status)&& ! empty($Decision)&& ! empty($Slip)) {
                                            ?>
                                                <div class="card">
                                                    <div class="card-header">
                                                        <strong class="card-title">Stand <?php echo $name ?>
                                                            <span class="badge badge-success float-right mt-1">Approved</span>
                                                        </strong>
                                                    </div>
                                                    <div class="card-body">
                                                        <p class="card-text">Your reservation for <strong><?php echo $name ?></strong>  is <strong>Payed and Approved</strong>.
                                                        </p>
                                                         <div class="table-data-feature">
                                                            <button class="item" data-toggle="tooltip" data-placement="top" title="Download Receipt" onclick="update_stand('<?php echo $id1 ?>');">
                                                                <i class="zmdi zmdi-download"></i>
                                                            </button>  
                                                        </div>
                                                    </div>
                                                </div>
                                        <?php
                                        } elseif (! empty($Status)|| ! empty($Slip)) {
                                            ?>
                                                <div class="card">
                                                    <div class="card-header">
                                                        <strong class="card-title"> Stand <?php echo $name ?>
                                                            <span class="badge badge-primary float-right mt-1">Waiting</span>
                                                        </strong>
                                                    </div>
                                                    <div class="card-body">
                                                        <p class="card-text">Your reservation Of <strong><?php echo $name ?></strong>  is <strong>Payed and its waiting to be Appoved</strong>.
                                                        </p>
                                                    </div>
                                                </div>
                                            <?php
                                        }else {
                                        ?>
                                                <div class="card">
                                                    <div class="card-header">
                                                        
                                                        <strong class="card-title"> Stand <?php echo $name ?>
                                                            <span class="badge badge-danger float-right mt-1">Pending</span>
                                                        </strong>
                                                    </div>
                                                    <div class="card-body">
                                                        <p class="card-text">Your reservation Of <strong><?php echo $name ?> is Reserved But need the Bank Slip to be Approved</strong>.
                                                        </p>
                                                        <p>
                                                            <form  action="#/" onsubmit="upload_bank_slip();return false;" method="post" >
                                                                <div style="display: none;"><input type="text" value="<?php echo $ResID ?>" name="ResID" id="ResID"></div>
                                                                Upload Bank Slip : <input type="file" id="slip" name="slip" class="form-control-file"> 
                                                                <br>
                                                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                                            </form>
                                                        </p>
                                                    </div>
                                                </div>
                                        <?php
                                        }
                                         

                                        ?>


                            <?php $a++; } } ?>

                            </div>
                        </div>
                        <?php include "footer.php"; ?>
                    </div>