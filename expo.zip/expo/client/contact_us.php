<div class="container-fluid">
                    
<!-- start of user -->
							<div id="new_testimonial_message"></div>
							<div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>New</strong> Suggestion
                                    </div>
                                    <div class="card-body card-block">

                            			<form action="#/" onsubmit="new_testimonial();return false;" method="post">

                            				<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">User Name <strong><?php echo "$username"; ?></strong></label>
                                                </div>
                                            </div>
                                            <div class="row form-group" style="display: none;" >
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="username" value="<?php echo "$username"; ?>" name="text-input" placeholder="Text" class="form-control">
                                                    <input type="text" id="email" value="<?php echo "$Email"; ?>" name="text-input" placeholder="Text" class="form-control">
                                                    <small class="form-text text-muted">This is a help text</small>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-2">
                                                    <label for="textarea-input" class=" form-control-label">Description</label>
                                                </div>
                                                <div class="col-12 col-md-10">
                                                    <textarea name="textarea-input" id="cont_message" rows="7" placeholder=" Write your Suggestion to be set to Rwanda Expo Manager" class="form-control"></textarea>
                                                </div>
                                            </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-paper-plane"></i> Send Suggestion
                                        </button>
                                        
                                    </div>
                            </form>

                                    
                                </div>
                            </div>

<!-- end of user -->
<?php include "footer.php"; ?>
</div>