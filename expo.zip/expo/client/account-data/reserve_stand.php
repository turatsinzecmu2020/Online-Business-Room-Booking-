
<?php
include "../../config/connection.php";
?>

<?php
if(!empty($_GET['q'])) 
{
 
 $id=$_GET['q'];
 
 ?>


<!-- select dept -->
<form action="" method="post" novalidate="novalidate" name="load_price">
<div class="form-group has-success">
<?php
    // count dept
        $sql3=" SELECT COUNT(*) AS stand_no FROM stands WHERE Dept='$id' and Status='0' ";
         $result3=$conn->query($sql3);
         while ($row3 = $result3->fetch_assoc()) {
            $stand_number=$row3['stand_no'];
        }
?>
    <label for="cc-name" class="control-label mb-1">Available Stand :   <strong><?php echo $stand_number;?></strong></label>
</div>

<div class="form-group has-success">

<?php

// track money of dept
        $sql4=" SELECT Stprice FROM department WHERE DeptID='$id'  ";
         $result4=$conn->query($sql4);
         while ($row4 = $result4->fetch_assoc()) {
            $dept_price=$row4['Stprice'];
        }
?>
    <label for="cc-name" class="control-label mb-1">Department Amount :   <strong><?php echo $dept_price;?> Frw</strong></label>
</div>

<div class="form-group has-success">
    <label for="cc-name" class="control-label mb-1">Choose Stand</label>
        <select id="stand_id" name="stand_id" id="price_amount" class="form-control">
            <option value="0">Please select Stand</option>
    <?php
        $sql2="SELECT * FROM stands WHERE Dept='$id' and Status='0' ";
        $result2=$conn->query($sql2);
        while ($row2 = $result2->fetch_assoc()) {
        $stand=$row2['StandNo'];
        $width=$row2['Width'];
        $heigth=$row2['Height'];
    ?>
            <option value="<?php echo $row2['StID'];?>"><?php echo $row2['StandNo'];?> Dimension (<?php echo $heigth;?>m X <?php echo $width;?>m) </option>
            <?php } ?>
        </select>
</div>

</form>


 <?php
   }
 ?>