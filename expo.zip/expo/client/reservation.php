<div class="container-fluid">
    <div id="Message2"></div>

<script type="text/javascript">
    function get_det(){
      var xmlhttp = new XMLHttpRequest();

      xmlhttp.onreadystatechange = function(){
        if(xmlhttp.readyState == 4){
          document.getElementById("d4").innerHTML = xmlhttp.responseText;
          }
      }
      xmlhttp.open("GET","account-data/reserve_stand.php?q="+document.choose_dept.dept_data.value,true);
      xmlhttp.send(null);
    }    
    function hideContent() {
    document.getElementById("message").style.display="none";
    document.getElementById("d4").style.display="block";  
    }
    function unhideContent() {
    document.getElementById("message").style.display="block"; 
    document.getElementById("d4").style.display="none"; 
}
</script>
                    
                                <div class="card">
                                    <div class="card-header">Stand Booking</div>
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h3 class="text-center title-2"><?php echo "$CustName"; ?> Fill the Data</h3>
                                        </div>
                                        <hr>
                                        <form action="#/" onsubmit="new_reservation();return false;"  method="post" novalidate="novalidate" name="choose_dept">

                                            <div style="display: none;"><input type="text" id="cust_id" value="<?php echo $CID ?>" name="cust_id"  ></div>
                                            
                                            <div class="form-group">
                                                <label for="cc-payment" class="control-label mb-1">Choose Department</label>
                                                    <select  id="dept_data" id="dept_id" name="dept_id" onchange="get_det();"    onfocus="get_det();" class="form-control">

                                                       <option value="">Please Select Department </option>
                                                           
                                                           <?php
                                                              $sql5="SELECT * from department";
                                                                $result5=$conn->query($sql5);
                                                                while ($row5 = $result5->fetch_assoc()) {
                                                                $DeptID=$row5['DeptID'];
                                                                $name=$row5['Name'];
                                                           ?>

                                                        <option value="<?php echo $row5['DeptID'];?>"  ><?php echo $name?></option> 
                                                            <?php } ?>
                                                    </select> 
                                            </div>

                                            <div id="d4" class="form-group has-success">
                                                
                                            </div>

                                            <!-- <div class="row">
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="cc-exp" class="control-label mb-1">Upload The Bank Slip</label>
                                                        <input type="file" id="file-input" name="file-input" class="form-control-file">
                                                        <span class="help-block" data-valmsg-for="cc-exp" data-valmsg-replace="true"></span>
                                                    </div>
                                                </div>
                                            </div> -->
                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fa fa-calendar fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Reserve Stand</span>
                                                    <span id="payment-button-sending" style="display:none;">Sending…</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>

<?php include "footer.php"; ?>
</div>