<div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1"> Welcome <?php echo "$CustName"; ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="row m-t-25">
                            <div class="col-md-6">
                                <div class="image">
                                     <a href="#">
                                        <img src="../assets/images/icon/expo.jpg" height="400 px" />
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="top-campaign">
                                    <h3 class="title-3 m-b-30">Stands OverView</h3>
                                    <div class="table-responsive">
                                        <table class="table table-top-campaign">
                                            <thead>
                                               <tr>
                                                    <td>Department</td>
                                                    <td>Total Stands</td>
                                                    <td>Available Stands</td>
                                                </tr> 
                                            </thead>
                                                <?php

                                                $sql5="SELECT * from department";
                                                $result5=$conn->query($sql5);

                                                $a=1;

                                                while ($row5 = $result5->fetch_assoc()) {
                                                $dept_id=$row5['DeptID'];
                                                $name=$row5['Name'];
                                                $numstands=$row5['NumStands'];
                                                $price=$row5['Stprice'];

                                                $sql6="SELECT count(*) AS AVAILABLE FROM stands where Dept='$dept_id' and Status='0' ";
                                                $result6=$conn->query($sql6);

                                                while ($row6 = $result6->fetch_assoc()) {
                                                $NUMBER=$row6['AVAILABLE'];

                                                ?>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo $a; ?> . <?php echo $name ?></td>
                                                    <td><?php echo $numstands ?></td>
                                                    <td><?php echo $NUMBER ?></td>
                                                </tr>
                                            </tbody>
                                            <?php $a++; } } ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                     
                        </div>
                        <?php include "footer.php"; ?>
                    </div>