
<?php 

// Database Connection 
include "../config/connection.php";
//Check for connection error

$data=$_GET['bank_slip'];

$sql5="SELECT * from reservation where ResID='$data' ";
  $result5=$conn->query($sql5);
  while ($row5 = $result5->fetch_assoc()) {
  $pdf=$row5['Slip'];
  $path = "certificate/";
  $file = $path.$pdf;
}
// The location of the PDF file 
// on the server 
$filename = "../client/bank_slip/$pdf"; 

// Header content type 
header("Content-type: application/pdf"); 

header("Content-Length: " . filesize($filename)); 

// Send the file to the browser. 
readfile($filename); 
?> 
