
<?php 

// Database Connection 
include "../config/connection.php";
//Check for connection error

$data=$_GET['slip_data'];

$sql5="SELECT * from customer where CID='$data' ";
  $result5=$conn->query($sql5);
  while ($row5 = $result5->fetch_assoc()) {
  $pdf=$row5['CommDocuments'];
  $path = "certificate/";
  $file = $path.$pdf;
}
// The location of the PDF file 
// on the server 
$filename = "../client/certificate/$pdf"; 

// Header content type 
header("Content-type: application/pdf"); 

header("Content-Length: " . filesize($filename)); 

// Send the file to the browser. 
readfile($filename); 
?> 
