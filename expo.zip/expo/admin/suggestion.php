                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
<div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Sender</th>
                                                <th>Email</th>
                                                <th>Message</th>
                                            </tr>
                                        </thead>
                                            <?php

                                                $sql5="SELECT * from suggestion";
                                                $result5=$conn->query($sql5);

                                                $a=1;

                                                while ($row5 = $result5->fetch_assoc()) {
                                                $SuggId=$row5['SuggID'];
                                                $sender=$row5['Sender'];
                                                $email=$row5['Email'];
                                                $message=$row5['Message'];
                                            ?> 
                                        <tbody>
                                            <tr>
                                                <td><?php echo $a; ?></td>
                                                <td><?php echo $sender; ?></td>
                                                <td><?php echo $email; ?></td>
                                                <td><?php echo $message; ?></td>
                                            </tr>                                           
                                        </tbody>
                                        <?php $a++; }  ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php include "footer.php"; ?>
                    </div>