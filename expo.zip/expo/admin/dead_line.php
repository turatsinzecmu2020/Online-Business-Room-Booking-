<div class="container-fluid">
    <div id="new_testimonial_message"></div>
                    
<div class="card">
                                    <div class="card-header">Settings Page</div>
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h3 class="text-center title-2">Dead Line</h3>
                                        </div>
                                        <hr>
                                        <form action="#/" onsubmit="dead_line();return false;" method="post" novalidate="novalidate">
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <label for="cc-exp" class="control-label mb-1">Choose Date</label>
                                                        <input id="dead_date" name="dead_date" type="date" class="form-control cc-exp" value="" data-val="true" data-val-required="Please enter the card expiration" data-val-cc-exp="Please enter a valid month and year" placeholder="MM / YY" autocomplete="cc-exp">
                                                        <span class="help-block" data-valmsg-for="cc-exp" data-valmsg-replace="true"></span>
                                                    </div>
                                                </div>
                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fa  fa-calendar-o fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Set Reservation Dead Line</span>
                                                    <span id="payment-button-sending" style="display:none;">Sending…</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>

<!-- end of user -->
<?php include "footer.php"; ?>
</div>