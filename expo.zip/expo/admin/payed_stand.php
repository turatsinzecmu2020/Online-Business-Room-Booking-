                <div class="container-fluid">
                     <div id="Message2" style="position:fixed;z-index:500;margin-top:-2%;"></div>
                     <br>
                        
                        <div id="loader_general_admin"></div>

                      <div class="row" id="loader_general_admin1">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <h3 class="title-5 m-b-35">Booked Rooms List</h3>
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2" id="Table1">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Date</th>
                                                <th>Name</th>
                                                <th>Nationality</th>
                                                <th>Identification</th>
                                                <th>Room</th>
                                                <th>Bank Slip</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                                <?php

                                                $sql5="SELECT customer.CID,customer.CustName,customer.Origin,customer.Identification,customer.CommDocuments,customer.Email,customer.Contacts,reservation.ResID,
                                                    reservation.CustID,reservation.StandID,reservation.Date,reservation.Res_Status,reservation.Decision,
                                                    stands.StID,stands.Dept,stands.StandNo,
                                                    department.Name
                                                    FROM customer ,reservation,stands,department
                                                    WHERE reservation.`CustID` = customer.`CID` and reservation.`StandID`=stands.`StID` and stands.`Dept`=department.`DeptID` and reservation.`Res_Status`='1' and reservation.`Decision`='0'";
                                                $result5=$conn->query($sql5);

                                                $a=1;

                                                while ($row5 = $result5->fetch_assoc()) {
                                                $stand_id=$row5['StID'];
                                                $reserv_id=$row5['ResID'];
                                                $client=$row5['CustName'];
                                                $country=$row5['Origin'];
                                                $ident=$row5['Identification'];
                                                $stand=$row5['StandNo'];
                                                $dept_name=$row5['Name'];
                                                $file_pdf=$row5['CommDocuments'];
                                                $reserv_date = new DateTime($row5['Date']); 


                                                $id1="Mine".$a;

                                                ?>                                        
                                        <tbody>
                                            <tr class="tr-shadow">
                                                <td id="<?php echo $id1; ?>"><?php echo $reserv_id ?></td>
                                                <td><?php echo $reserv_date->format('d/m/Y');?> </td>
                                                <td><?php echo $client ?></td>
                                                <td><?php echo $country ?></td>
                                                <td >
                                                    <a href="view_identification.php?slip_data=<?php echo $row5['CID']; ?>" target="_blank">
                                                    <i class="fas fa-list-alt"></i> View Doc</a> 
                                                </td>
                                                <td ><?php echo $dept_name ?><?php echo $stand ?>  </td>
                                                <td >
                                                    <a href="view_bank_slip.php?bank_slip=<?php echo $row5['ResID']; ?>" target="_blank">
                                                    <i class="fas fa-file-text"></i> Bank Slip</a> 
                                                </td>
                                                <td>
                                                    <div class="table-data-feature">

                                                        <div style="display: none;">
                                                            <input type="text" id="reserv_id" name="" value="<?php echo $reserv_id ?>" >
                                                        </div>

                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Approve" onclick="approve_stand_data('<?php echo $id1 ?>');">
                                                            <i class="zmdi zmdi-thumb-up"></i>
                                                        </button>

                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Decline" onclick="decline_stand('<?php echo $id1 ?>');" >
                                                            <i class="zmdi zmdi-block"></i>
                                                            
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr class="spacer"></tr>
                                            
                                        </tbody>
                                        <?php $a++; }  ?>
                                    </table>
                                </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                        <?php include "footer.php"; ?>
                    </div>