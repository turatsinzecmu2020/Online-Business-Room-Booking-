<?php
include "../../config/connection.php";
?>
 

 
 <div class="row" id="loader_general_admin2">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <br>
                                
                                <button  class=" title-5 m-b-35 au-btn au-btn-icon au-btn--blue au-btn--small" onclick="location.reload()">
                                            <i class="zmdi zmdi-menu"></i>view records</button>
                                
                                <div class="table-responsive table-responsive-data">

                                <div class="col-lg-12">
                                    <div class="card">
                                    <div class="card-header">New Stand</div>
                                    <div class="card-body">
                                        <form action="#/" onsubmit="new_stand();return false;"  method="post" novalidate="novalidate">
                                            <div class="form-group has-success">
                                                <label for="cc-name" class="control-label mb-1">Department Name</label>
                                                    <select name="dept" id="dept" class="form-control-sm form-control">
                                                        <option value="0">Please select Department</option>
                                                        <?php

                                                        $sql5="SELECT * from department";
                                                        $result5=$conn->query($sql5);

                                                        while ($row5 = $result5->fetch_assoc()) {
                                                        $DeptID=$row5['DeptID'];
                                                        $name=$row5['Name'];

                                                        ?>
                                                        
                                                        <option value="<?php echo $DeptID ?>"><?php echo $name ?></option>
                                                    <?php } ?>
                                                    </select>
                                                <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
                                            </div>

                                            <div class="form-group">
                                                <label for="cc-payment" class="control-label mb-1">Stand Identification No</label>
                                                <input id="standno" name="standno" type="text" class="form-control" aria-required="true" aria-invalid="false" >
                                            </div>

                                            <div class="form-group">
                                                <label for="cc-payment" class="control-label mb-1">Stand Height</label>
                                                <input id="height" name="height" type="text" class="form-control" aria-required="true" aria-invalid="false" >
                                            </div>

                                            <div class="form-group">
                                                <label for="cc-payment" class="control-label mb-1">Stand Width</label>
                                                <input id="width" name="width" type="text" class="form-control" aria-required="true" aria-invalid="false" >
                                            </div>
                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fa fa-lock fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Save New Stand</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                                </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>