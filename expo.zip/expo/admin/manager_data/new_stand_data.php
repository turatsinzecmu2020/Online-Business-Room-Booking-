<!DOCTYPE html>



<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">


    <!-- Fontfaces CSS-->
    <link href="../../assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="../../assets/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="../../assets/vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="../../assets/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="../../assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="../../assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="../../assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="../../assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="../../assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="../../assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="../../assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="../../assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="../../assets/css/theme.css" rel="stylesheet" media="all">

        <!-- Jquery JS-->
    <script src="../../assets/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="../../assets/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="../../assets/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="../../assets/vendor/slick/slick.min.js">
    </script>
    <script src="../../assets/vendor/wow/wow.min.js"></script>
    <script src="../../assets/vendor/animsition/animsition.min.js"></script>
    <script src="../../assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="../../assets/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="../../assets/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="../../assets/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="../../assets/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="../../assets/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="../../assets/vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="../../assets/js/main.js"></script>
    <script src="../../js/main.js"></script>

    </head>

<body>


<?php
include "../../config/connection.php";
?>

<?php 

    $dept=$_POST['dept'];
    $standno=$_POST['standno'];
    $height=$_POST['height'];
    $width=$_POST['width'];

    $sql5="SELECT COUNT(Stands) AS number FROM stand_count where DeptID='$dept' ";
        $result5=$conn->query($sql5);

        while ($row5 = $result5->fetch_assoc()) {
        $rem_stand=$row5['number'];

    $sql6="SELECT * FROM stand_count where DeptID='$dept' ";
        $result6=$conn->query($sql6);

        while ($row6 = $result6->fetch_assoc()) {
        $rem_stand=$row6['Stands'];
        $done_stand=1;
        $actual_stand=$rem_stand-$done_stand;

        if (empty($rem_stand)) {
            ?>
                <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                    <span class="badge badge-pill badge-danger">Done</span>
                        There is no Stand left for this Department.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close" style="" onclick="location.reload();">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <br>
                </div>
            <?php
        } else {

            $sql="INSERT INTO stands( `Dept`, `StandNo`, `Height`, `Width`, `Status`)
            VALUE('$dept','$standno','$height','$width','0')";

            $sql1="UPDATE stand_count set Stands='$actual_stand' where DeptID='$dept'";

            if ($conn->query($sql)&&$conn->query($sql1)==TRUE) {
                ?>
                <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
                    <span class="badge badge-pill badge-success">Done</span>
                        You have Succefully added New Stand .
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close" style="" onclick="location.reload();">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <br>
                </div>
                <?php

                }else{
                    ?>
                    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                        <span class="badge badge-pill badge-danger">Error</span>
                        Something went wrong. Please try again And try to refresh the page please.
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                    </div>
                    <?php
                }
        }
    }
}
        



?>

</body>
</html>