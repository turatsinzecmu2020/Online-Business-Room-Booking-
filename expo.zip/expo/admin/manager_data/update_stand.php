<?php
include "../../config/connection.php";
?>
 
<?php
$StID=$_POST['StID'];

$sql="SELECT * from stands where StID='$StID'";
$result=$conn->query($sql);

$a=1;

while ($row = $result->fetch_assoc()) {
    $StID=$row['StID'];
    $standno=$row['StandNo'];
    $heigth=$row['Height'];
    $width=$row['Width'];

  $id1="Mine".$a;
  $id2="Mine1".$a;

}

?>
 
 <div class="row" id="loader_general_admin2">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <br>
                                
                                <button  class=" title-5 m-b-35 au-btn au-btn-icon au-btn--blue au-btn--small" onclick="location.reload()">
                                            <i class="zmdi zmdi-menu"></i>view records</button>
                                
                                <div class="table-responsive table-responsive-data">
                                    <div id="Message2"></div>
                            

                                <div class="col-lg-12">
                                    <div class="card">
                                    <div class="card-header">Update <strong><?php echo $standno; ?></strong> Stand Data</div>
                                    <div class="card-body">
                                        <form  action="#/" onsubmit="update_stand_data();return false;" method="post" novalidate="novalidate">
                                            <div style="display: none;">
                                                <input id="StID" name="StID"  value="<?php echo $StID; ?>">
                                            </div>
                                            <div class="form-group has-success">
                                                <label for="cc-name" class="control-label mb-1">Stand Identification</label>
                                                <input id="standno" name="standno" type="text" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the name on card" autocomplete="cc-name" aria-required="true" aria-invalid="false" aria-describedby="cc-name-error" value="<?php echo $standno; ?>">
                                                <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
                                            </div>

                                            <div class="form-group">
                                                <label for="cc-payment" class="control-label mb-1">Stand Heigth</label>
                                                <input id="heigth" name="heigth" type="text" class="form-control" aria-required="true" aria-invalid="false" value="<?php echo $heigth; ?>">
                                            </div>

                                            <div class="form-group">
                                                <label for="cc-payment" class="control-label mb-1">Stand Width</label>
                                                <input id="width" name="width" type="text" class="form-control" aria-required="true" aria-invalid="false" value="<?php echo $width; ?>">
                                            </div>

                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fa fa-tasks fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Update Stand</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                                </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>