						<div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2019 All rights reserved By Expo Rwanda | Designed by <a href="https://colorlib.com">NP Tech</a>.</p>
                                </div>
                            </div>
                        </div>