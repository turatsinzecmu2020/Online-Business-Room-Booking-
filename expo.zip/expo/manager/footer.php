						<div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2019 All rights reserved By Online Business Room Booking | Designed by <a href="#">Alex</a>.</p>
                                </div>
                            </div>
                        </div>