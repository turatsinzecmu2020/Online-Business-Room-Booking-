<div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1"> Welcome <?php echo "$username"; ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="row m-t-25">
                            <div class="col-md-6">
                                <div class="image">
                                     <a href="#">
                                        <img src="../assets/images/icon/expo.jpg" height="400 px" />
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="top-campaign">
                                    <h3 class="title-3 m-b-30">Rooms OverView</h3>
                                    <div class="table-responsive">
                                        <table class="table table-top-campaign">
                                            <thead>
                                               <tr>
                                                    <td>Room Type</td>
                                                    <td>Rooms</td>
                                                </tr> 
                                            </thead>
                                                <?php

                                                $sql5="SELECT * from department";
                                                $result5=$conn->query($sql5);

                                                $a=1;

                                                while ($row5 = $result5->fetch_assoc()) {
                                                $name=$row5['Name'];
                                                $numstands=$row5['NumStands'];
                                                $price=$row5['Stprice'];

                                                $id1="Mine".$a;
                                                $id2="Mine1".$a;

                                                ?>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo $a; ?> . <?php echo $name ?></td>
                                                    <td><?php echo $numstands ?></td>
                                                </tr>
                                            </tbody>
                                            <?php $a++; } ?>
                                        </table>
                                    </div>
                                    <div class="au-task__footer">
                                            <a href="index.php?department"><button class="au-btn au-btn-load js-load-btn">load more</button></a>
                                        </div>
                                </div>
                            </div>
                        </div>
                     
                        </div>
                        <?php include "footer.php"; ?>
                    </div>